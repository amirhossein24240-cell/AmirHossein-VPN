package com.amirhossein.vpn;

import android.app.Activity;
import android.content.Intent;
import android.net.VpnService;
import android.os.Bundle;
import android.view.Gravity;
import android.view.View;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

import com.wireguard.android.backend.Backend;
import com.wireguard.android.backend.GoBackend;
import com.wireguard.android.backend.Tunnel;
import com.wireguard.config.Config;

import java.io.ByteArrayInputStream;
import java.nio.charset.StandardCharsets;

public class MainActivity extends Activity {
    private static final int VPN_PERMISSION_REQUEST = 701;
    private Backend backend;
    private Config importedConfig;
    private String configName = "Imported tunnel";
    private TextView status;
    private TextView server;
    private Button connectButton;

    private final Tunnel tunnel = new Tunnel() {
        @Override public String getName() { return "amirhossein"; }
        @Override public void onStateChange(State newState) {
            runOnUiThread(() -> setStatus("وضعیت: " + newState.name()));
        }
    };

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        backend = new GoBackend(this);
        buildScreen();
    }

    private void buildScreen() {
        LinearLayout page = new LinearLayout(this);
        page.setOrientation(LinearLayout.VERTICAL);
        page.setGravity(Gravity.CENTER_HORIZONTAL);
        page.setPadding(28, 42, 28, 28);
        page.setBackgroundColor(0xFF0B1425);

        TextView title = new TextView(this);
        title.setText("🛡  AmirHossein VPN");
        title.setTextColor(0xFFFFFFFF);
        title.setTextSize(27);
        title.setGravity(Gravity.CENTER);
        page.addView(title, matchWrap());

        TextView subtitle = new TextView(this);
        subtitle.setText("اتصال امن با WireGuard");
        subtitle.setTextColor(0xFF9DB3D1);
        subtitle.setTextSize(15);
        subtitle.setGravity(Gravity.CENTER);
        LinearLayout.LayoutParams subParams = matchWrap();
        subParams.topMargin = 12;
        page.addView(subtitle, subParams);

        status = new TextView(this);
        status.setText("وضعیت: آماده‌به‌کار");
        status.setTextColor(0xFFFFFFFF);
        status.setTextSize(19);
        status.setGravity(Gravity.CENTER);
        LinearLayout.LayoutParams statusParams = matchWrap();
        statusParams.topMargin = 55;
        statusParams.bottomMargin = 24;
        page.addView(status, statusParams);

        server = new TextView(this);
        server.setText("سرور: هنوز کانفیگی وارد نشده");
        server.setTextColor(0xFFB8C8DC);
        server.setTextSize(14);
        server.setGravity(Gravity.CENTER);
        page.addView(server, matchWrap());

        Button importButton = makeButton("وارد کردن فایل کانفیگ (.conf)");
        importButton.setOnClickListener(v -> chooseConfig());
        addButton(page, importButton);

        connectButton = makeButton("اتصال");
        connectButton.setOnClickListener(v -> requestConnect());
        addButton(page, connectButton);

        Button disconnectButton = makeButton("قطع اتصال");
        disconnectButton.setOnClickListener(v -> disconnect());
        addButton(page, disconnectButton);

        TextView note = new TextView(this);
        note.setText("برای اتصال واقعی، فایل کانفیگ معتبر سرور WireGuard لازم است. این نسخه سرور عمومی ناشناس را خودکار استفاده نمی‌کند.");
        note.setTextColor(0xFF8195B1);
        note.setTextSize(12);
        note.setGravity(Gravity.CENTER);
        LinearLayout.LayoutParams noteParams = matchWrap();
        noteParams.topMargin = 30;
        page.addView(note, noteParams);

        setContentView(page);
        refreshButtons();
    }

    private LinearLayout.LayoutParams matchWrap() {
        return new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT,
                LinearLayout.LayoutParams.WRAP_CONTENT);
    }

    private Button makeButton(String label) {
        Button b = new Button(this);
        b.setText(label);
        b.setAllCaps(false);
        b.setTextSize(15);
        return b;
    }

    private void addButton(LinearLayout page, Button b) {
        LinearLayout.LayoutParams p = matchWrap();
        p.topMargin = 14;
        page.addView(b, p);
    }

    private void chooseConfig() {
        Intent intent = new Intent(Intent.ACTION_OPEN_DOCUMENT);
        intent.addCategory(Intent.CATEGORY_OPENABLE);
        intent.setType("*/*");
        startActivityForResult(intent, 702);
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == 702 && resultCode == RESULT_OK && data != null && data.getData() != null) {
            try (java.io.InputStream in = getContentResolver().openInputStream(data.getData())) {
                if (in == null) throw new IllegalStateException("فایل خوانده نشد");
                java.io.ByteArrayOutputStream buffer = new java.io.ByteArrayOutputStream();
                byte[] chunk = new byte[8192];
                int count;
                while ((count = in.read(chunk)) != -1) buffer.write(chunk, 0, count);
                byte[] bytes = buffer.toByteArray();
                importedConfig = Config.parse(new ByteArrayInputStream(bytes));
                configName = data.getData().getLastPathSegment();
                server.setText("کانفیگ بارگذاری شد: " + configName);
                setStatus("وضعیت: کانفیگ آماده است");
                refreshButtons();
            } catch (Exception e) {
                importedConfig = null;
                Toast.makeText(this, "فایل کانفیگ معتبر نیست: " + e.getMessage(), Toast.LENGTH_LONG).show();
                refreshButtons();
            }
        } else if (requestCode == VPN_PERMISSION_REQUEST) {
            if (resultCode == RESULT_OK) startTunnel();
            else Toast.makeText(this, "مجوز VPN داده نشد.", Toast.LENGTH_LONG).show();
        }
    }

    private void requestConnect() {
        if (importedConfig == null) {
            Toast.makeText(this, "ابتدا فایل کانفیگ معتبر WireGuard را وارد کن.", Toast.LENGTH_LONG).show();
            return;
        }
        Intent prepare = VpnService.prepare(this);
        if (prepare != null) startActivityForResult(prepare, VPN_PERMISSION_REQUEST);
        else startTunnel();
    }

    private void startTunnel() {
        new Thread(() -> {
            try {
                backend.setState(tunnel, Tunnel.State.UP, importedConfig);
                runOnUiThread(() -> {
                    setStatus("وضعیت: درخواست اتصال ارسال شد");
                    Toast.makeText(this, "درخواست اتصال WireGuard ارسال شد.", Toast.LENGTH_SHORT).show();
                });
            } catch (Exception e) {
                runOnUiThread(() -> {
                    setStatus("وضعیت: خطا در اتصال");
                    Toast.makeText(this, "اتصال ناموفق: " + e.getMessage(), Toast.LENGTH_LONG).show();
                });
            }
        }).start();
    }

    private void disconnect() {
        new Thread(() -> {
            try {
                backend.setState(tunnel, Tunnel.State.DOWN, null);
                runOnUiThread(() -> setStatus("وضعیت: قطع‌شده"));
            } catch (Exception e) {
                runOnUiThread(() -> Toast.makeText(this, "خطا در قطع اتصال: " + e.getMessage(), Toast.LENGTH_LONG).show());
            }
        }).start();
    }

    private void setStatus(String value) {
        status.setText(value);
        refreshButtons();
    }

    private void refreshButtons() {
        if (connectButton != null) connectButton.setEnabled(importedConfig != null);
    }
}
